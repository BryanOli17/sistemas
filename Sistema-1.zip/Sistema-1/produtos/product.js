function changeImage(src) {
    document.getElementById("product-img").src = src;
  }
  
  function addToCart() {
    alert("Produto adicionado ao carrinho!");
  }
  
  function buyNow() {
    alert("Redirecionando para o pagamento...");
  }
  